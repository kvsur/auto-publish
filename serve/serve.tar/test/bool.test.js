console.log(new Boolean('false'))

console.log(!!parseInt('0000'));