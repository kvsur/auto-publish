#!/bin/bash
echo 'hello world'
touch fuckyou.js
exit