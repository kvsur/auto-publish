#!/bin/bash
echo "process: /d/projects/znkf-publish/publish/serve/test/${1}.test.js  use node env"
node d:/projects/znkf-publish/publish/serve/test/${1}.test.js
exit;
