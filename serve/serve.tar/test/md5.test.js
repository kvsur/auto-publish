const fs = require('fs');
const md5 = require('md5');
const path = require('path');

console.log(md5('Authorization'));