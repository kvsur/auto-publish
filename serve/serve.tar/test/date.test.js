console.log(new Date().toLocaleString('zh-CN', {hour12: false}));
console.log(new Date().toLocaleString('zh-CN', {hour12: false, day: '2-digit', month: '2-digit', year: 'numeric'}));