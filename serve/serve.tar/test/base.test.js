var Base64 = require('js-base64').Base64;

console.log(Base64.encode('webapp:123456'));