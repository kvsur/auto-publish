module.exports = {
    success: 'green', // 成功输出内容
    error: 'red', // 错误输出内容
    warning: 'yellow', // 警告输出内容 
};