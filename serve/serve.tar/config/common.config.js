module.exports = {
    watchOptions: {
        persistent: false, // 如果当前目录正在被监听，则不继续进行添加监听的操作
        recursive: false, // 只对一级子目录进行监听
    },
    SCRET: 'ZNKF_PUBLISH',
};