/**
 * 所有配置如果本项目不熟目录没有更改的情况建议不要轻易进行更改 from lc
 */
module.exports = {
    PACKAGE_DIR_ROOT: "d:/puppet_data/puppet",
    DEPLOY_PATH: "d:/www/html/ai",
    DIST_PATH: "d:/www/html/ai/archive_dist",
    ARCHIVE_PATH: "d:/www/html/ai/archive_package",
}
